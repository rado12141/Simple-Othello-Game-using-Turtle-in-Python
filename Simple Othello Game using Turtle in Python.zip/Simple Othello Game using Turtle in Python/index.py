import othello

def main():

    game = othello.Othello()
    game.draw_board()
    game.initialize_board()


    game.run()


main()
